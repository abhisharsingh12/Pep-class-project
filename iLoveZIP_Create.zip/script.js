const rows = 5;
const cols = 8;

let theatre = JSON.parse(localStorage.getItem("theatre")) || {
  Avengers: { price: 200, seats: createSeats() },
  Jawan: { price: 150, seats: createSeats() },
  Pathaan: { price: 180, seats: createSeats() }
};

function createSeats() {
  let arr = [];
  for (let i = 0; i < rows; i++) {
    arr[i] = [];
    for (let j = 0; j < cols; j++) {
      arr[i][j] = "available";
    }
  }
  return arr;
}

// Save movie selection
function selectMovie(movie) {
  localStorage.setItem("selectedMovie", movie);
  localStorage.setItem("theatre", JSON.stringify(theatre));
  window.location.href = "seats.html";
}

// Load seats page
if (window.location.pathname.includes("seats.html")) {
  let movie = localStorage.getItem("selectedMovie");
  let movieData = theatre[movie];

  document.getElementById("movieTitle").innerText = movie + " - ₹" + movieData.price;

  let container = document.getElementById("seatContainer");
  let count = document.getElementById("count");
  let total = document.getElementById("total");

  renderSeats(movieData.seats);

  function renderSeats(seats) {
    container.innerHTML = "";
    let index = 0;

    for (let i = 0; i < rows; i++) {
      for (let j = 0; j < cols; j++) {
        let seat = document.createElement("div");
        seat.classList.add("seat");

        if (seats[i][j] === "booked") {
          seat.classList.add("booked");
        }

        seat.addEventListener("click", function () {
          if (seats[i][j] === "available") {
            seat.classList.toggle("selected");
            updateSelection();
          }
        });

        container.appendChild(seat);
        index++;
      }
    }
  }

  function updateSelection() {
    let selected = document.querySelectorAll(".selected");
    count.innerText = selected.length;
    total.innerText = selected.length * movieData.price;
  }

  window.confirmBooking = function () {
    let seatDivs = document.querySelectorAll(".seat");
    let index = 0;

    for (let i = 0; i < rows; i++) {
      for (let j = 0; j < cols; j++) {
        if (seatDivs[index].classList.contains("selected")) {
          movieData.seats[i][j] = "booked";
        }
        index++;
      }
    }

    theatre[movie] = movieData;
    localStorage.setItem("theatre", JSON.stringify(theatre));
    localStorage.setItem("lastBooking", selected.length);

    window.location.href = "confirmation.html";
  };
}

// Confirmation Page
if (window.location.pathname.includes("confirmation.html")) {
  let movie = localStorage.getItem("selectedMovie");
  let seatsBooked = localStorage.getItem("lastBooking");

  document.getElementById("summary").innerText =
    "You booked " + seatsBooked + " seats for " + movie;
}